SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [tbl_archive_fields](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[archive_year] [varchar](10) NULL,
	[field_name] [varchar](100) NOT NULL,
	[field_description] [varchar](100) NOT NULL,
	[field_type] [char](1) NOT NULL,
	[field_sort] [varchar](10) NOT NULL,
	[sorter] [int] NOT NULL,
 CONSTRAINT [PK_tbl_archive_fields_2015] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 100) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [tbl_archive_fields] ADD  DEFAULT ('asc') FOR [field_sort]
GO

SET IDENTITY_INSERT [tbl_archive_fields] ON
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (1, N'2015', N'counts', N'Simple count', N'H', N'asc', 1)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (2, N'2015', N'ch_reported', N'Chronically homeless households', N'H', N'desc', 2)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (3, N'2015', N'total_hh_income_intake_bracket', N'Household income - total - at entry **', N'H', N'asc', 3)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (4, N'2015', N'total_hh_income_latest_bracket', N'Household income - total - latest **', N'H', N'asc', 4)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (5, N'2015', N'total_hh_income_change_bracket', N'Household income - total change from entry to latest **', N'H', N'asc', 5)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (6, N'2015', N'household_type', N'Household type **', N'H', N'asc', 6)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (7, N'2015', N'age_max', N'Age', N'C', N'asc', 1)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (8, N'2015', N'age_bracket', N'Age bracket', N'C', N'asc', 2)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (9, N'2015', N'chronic_condition', N'Chronic health condition', N'C', N'desc', 3)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (10, N'2015', N'ch_reported', N'Chronically homeless upon entry **', N'C', N'desc', 4)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (11, N'2015', N'developmental_disability', N'Developmental disability', N'C', N'desc', 5)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (12, N'2015', N'domestic_violence', N'Domestic violence survivor', N'C', N'desc', 6)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (13, N'2015', N'exit_destination', N' Exit destination **', N'C', N'asc', 7)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (14, N'2015', N'gender', N'Gender', N'C', N'asc', 8)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (15, N'2015', N'insurance_intake', N'Health insurance - at entry **', N'C', N'desc', 9)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (16, N'2015', N'insurance_latest', N'Health insurance - latest **', N'C', N'desc', 10)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (17, N'2015', N'hiv_aids', N'HIV / AIDS', N'C', N'desc', 11)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (18, N'2015', N'household_count', N'Household size **', N'C', N'asc', 12)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (19, N'2015', N'household_type__2', N'Household type **', N'C', N'asc', 13)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (20, N'2015', N'length_of_stay_bracket', N'Length of stay (in brackets) **', N'C', N'asc', 14)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (21, N'2015', N'length_of_stay', N'Length of stay (in days) **', N'C', N'asc', 15)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (22, N'2015', N'medicaid_intake', N'Medicaid coverage - at entry **', N'C', N'desc', 16)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (23, N'2015', N'medicaid_latest', N'Medicaid coverage - latest **', N'C', N'desc', 17)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (24, N'2015', N'mental_health_prob', N'Mental health problem', N'C', N'desc', 18)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (25, N'2015', N'employment_income_intake_bracket', N'Personal income - employment only - at entry **', N'C', N'asc', 21)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (26, N'2015', N'employment_income_latest_bracket', N'Personal income - employment only - latest **', N'C', N'asc', 22)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (27, N'2015', N'total_income_intake_bracket', N'Personal income - all cash - at entry **', N'C', N'asc', 19)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (28, N'2015', N'total_income_latest_bracket', N'Personal income - all cash - latest **', N'C', N'asc', 20)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (29, N'2015', N'total_income_change_bracket', N'Personal income - total change from entry to latest **', N'C', N'asc', 23)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (30, N'2015', N'physical_disability', N'Physical disability', N'C', N'desc', 24)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (31, N'2015', N'prior_living', N'Prior living situation **', N'C', N'asc', 25)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (32, N'2015', N'race', N'Race', N'C', N'asc', 26)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (33, N'2015', N'substance_abuse', N'Substance abuse', N'C', N'asc', 27)
INSERT [tbl_archive_fields] ([id], [archive_year], [field_name], [field_description], [field_type], [field_sort], [sorter]) VALUES (34, N'2015', N'vet', N'Veteran', N'C', N'desc', 28)
SET IDENTITY_INSERT [tbl_archive_fields] OFF

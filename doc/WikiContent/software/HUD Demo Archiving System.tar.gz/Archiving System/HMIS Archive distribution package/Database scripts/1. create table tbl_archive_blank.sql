SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [tbl_archive_blank](
	[client_ID] [int] NOT NULL,
	[household_ID] [int] NULL,
	[date_intake] [date] NULL,
	[date_exit] [date] NULL,
	[primary_client] [int] NULL,
	[primary_client_ID] [int] NULL,
	[program_type_ID] [int] NULL,
	[program_type] [varchar](256) NULL,
	[household_count] [int] NULL,
	[adult_count] [int] NULL,
	[child_count] [int] NULL,
	[unknown_count] [int] NULL,
	[household_type] [varchar](256) NULL,
	[total_income_intake] [money] NULL,
	[total_income_latest] [money] NULL,
	[total_income_change] [money] NULL,
	[total_income_change_bracket] [varchar](256) NULL,
	[total_income_intake_bracket] [varchar](256) NULL,
	[total_income_latest_bracket] [varchar](256) NULL,
	[emp_amt_intake] [money] NULL,
	[emp_amt_latest] [money] NULL,
	[employment_income_intake_bracket] [varchar](256) NULL,
	[employment_income_latest_bracket] [varchar](256) NULL,
	[total_hh_income_intake] [money] NULL,
	[total_hh_income_latest] [money] NULL,
	[total_hh_income_change] [money] NULL,
	[total_hh_income_intake_bracket] [varchar](256) NULL,
	[total_hh_income_latest_bracket] [varchar](256) NULL,
	[total_hh_income_change_bracket] [varchar](256) NULL,
	[ch_reported] [varchar](256) NULL,
	[insurance_intake] [varchar](256) NULL,
	[insurance_latest] [varchar](256) NULL,
	[length_of_stay] [int] NULL,
	[length_of_stay_bracket] [varchar](256) NULL,
	[medicaid_intake] [varchar](256) NULL,
	[medicaid_latest] [varchar](256) NULL,
	[prior_living] [varchar](500) NULL,
	[exit_destination] [varchar](500) NULL,
	[age_max] [varchar](256) NULL,
	[age_bracket] [varchar](256) NULL,
	[race] [varchar](500) NULL,
	[vet] [varchar](256) NULL,
	[gender] [varchar](256) NULL,
	[chronic_condition] [varchar](256) NULL,
	[developmental_disability] [varchar](256) NULL,
	[domestic_violence] [varchar](256) NULL,
	[hiv_aids] [varchar](256) NULL,
	[mental_health_prob] [varchar](256) NULL,
	[physical_disability] [varchar](256) NULL,
	[substance_abuse] [varchar](256) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/*
You will need to load the data using your own queries according to your HMIS database configuration.
*/


﻿function Qget(what) {
    return document.getElementById(what);
}

function expando_collapso(what, what2, method) {
    // method is 'expando' or 'collapso' if you want to force a particular maneuvre.

    if (Qget(what + "image") != null && Qget(what + "image").src.indexOf('minus') == -1) {
        // expando!
        if (method != 'collapso') {
            Qget(what + "image").src = Qget(what + "image").src.replace("plus", "minus");
            if (Qget(what + "table"))
                Qget(what + "table").style.display = '';
            if (Qget(what2 + "table"))
                Qget(what2 + "table").style.display = '';
        }
    }
    else {
        //collapso!
        if (method != 'expando') {
            if (Qget(what + 'image')) {

                Qget(what + "image").src = Qget(what + "image").src.replace("minus", "plus");
            }
            if (Qget(what + 'table'))
                Qget(what + 'table').style.display = 'none';

            if (Qget(what2 + 'table'))
                Qget(what2 + 'table').style.display = 'none';
        }
    }
}

function launchHelp(location) {

    var left = screen.width - 620;
    var height = screen.height - 100;
    launchWindow(location, 'HMISarc Help', 600, height, 'scrollbars=yes,resizable=yes,menubar=no,location=no,directories=no,toolbar=no,left=' + left, false);



}

function launchWindow(strURL, strName, intWidth, intHeight, strProperties, bModal) {
    var mywin;
    var intVersion;
    var dummyDate = new Date();

    if (screen.width <= 1024) {
        if (intWidth == -1) intWidth = 950;
        if (intHeight == -1) intHeight = 500;
    }
    else if (screen.width <= 1280) {
        if (intWidth == -1) intWidth = 1100;
        if (intHeight == -1) intHeight = 700;
    }
    else if (screen.width <= 1366) {
        if (intWidth == -1) intWidth = 1200;
        if (intHeight == -1) intHeight = 600;
    }
    else if (screen.width <= 1440) {
        if (intWidth == -1) intWidth = 1300;
        if (intHeight == -1) intHeight = 750;
    }
    else //if (screen.width <= 1920)
    {
        if (intWidth == -1) intWidth = 1500;
        if (intHeight == -1) intHeight = 900;
    }

    if (strProperties == "") strProperties = "scrollbars=yes,resizable=yes,menubar=no,location=no,directories=no,toolbar=no";
    if (strProperties.indexOf('left') == -1) strProperties += ",left=" + parseInt((screen.width - intWidth) / 2);
    if (strProperties.indexOf('top') == -1) {
        var topper = parseInt((screen.height - 70 - intHeight) / 2);
        if (topper < 0) topper = 0;
        strProperties += ",top=" + topper;
    }

    strProperties = "status=yes,height=" + intHeight + ",width=" + intWidth + "," + strProperties;

    // replace all non-alphacharacters with X
    if (strName.replace)
        strName = strName.replace(/\W/g, "X");

    // lower case the string
    strName = strName.toLowerCase();

    if (bModal) {
        mywin = window.showModalDialog(strURL, window, strProperties);
    }
    else {
        mywin = window.open(strURL, strName, strProperties);
    }

    if (mywin != null) {
        mywin.name = strName;
        mywin.focus();
        if (mywin.opener == null) mywin.opener = self;
    }

    return mywin;

}

//Finds y value of given object
function findPos(objId) {
    var obj = document.getElementById(objId);
    var curtop = 0;
    if (obj.offsetParent) {
        do {
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
        return [curtop];
    }
}

﻿Public Class _Default
    Inherits System.Web.UI.Page

    'This sample HMISarc solution is a product of the HMIS Data Lab at the Partnership Center and HUD.

#Region "Events"


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.Master.Page.Title = "HMISarc " & My.Settings.ArchiveYear

        Dim fieldType As String

        If Not Page.IsPostBack Then

            'Load project types list from those which actually appear in the archive:
            LoadFilterChoices(Me.lbPtypes, "program_type")

            If Me.rblHorC.SelectedValue = "households" Then
                fieldType = "H"
            Else
                fieldType = "C"
            End If

            LoadFields(Me.ddl1, Me.lbFilter1, fieldType)
            'The remaining fields can only be used for output on clients, not households.
            LoadFields(Me.ddl2, Me.lbFilter2, "C")
            LoadFields(Me.ddl3, Me.lbFilter3, "C")
            LoadFields(Me.ddl4, Me.lbFilter4, "C")

            Me.ddl1.SelectedIndex = 0

        End If

        'Now that all the other dropdown lists have possible field choices, it's safe to make the first choice un-clickable.
        Me.ddl1.Items(0).Attributes.Add("disabled", "disabled")
        Me.ddl2.Items(0).Attributes.Add("disabled", "disabled")
        Me.ddl3.Items(0).Attributes.Add("disabled", "disabled")
        Me.ddl4.Items(0).Attributes.Add("disabled", "disabled")

    End Sub


    Protected Sub lbPtypes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbPtypes.SelectedIndexChanged
        Me.phResults.Visible = False
    End Sub


    Protected Sub rblHorC_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rblHorC.SelectedIndexChanged
        If Me.rblHorC.SelectedValue = "households" Then
            'Counting households
            LoadFields(Me.ddl1, Me.lbFilter1, "H")
            'Close down all the other fields:
            ExpandoCollapso(Me.butField2, Me.Panel2, 0)
            ExpandoCollapso(Me.butField3, Me.Panel3, 0)
            ExpandoCollapso(Me.butField4, Me.Panel4, 0)
        Else
            'Counting clients/people.  Load the first field by default.  If the user selects another field, it will be populated at that time.
            LoadFields(Me.ddl1, Me.lbFilter1, "C")
        End If
    End Sub


    Protected Sub ddl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl1.SelectedIndexChanged

        Dim showMoreFields As Boolean = False

        If Me.ddl1.SelectedIndex > 0 Then
            Me.phStep34.Visible = True
            If Me.rblHorC.SelectedValue = "clients" Then showMoreFields = True
        End If

        Me.butField2.Visible = showMoreFields
        Me.butField3.Visible = showMoreFields
        Me.butField4.Visible = showMoreFields


        LoadFilterChoices(lbFilter1, Me.ddl1.SelectedValue.Replace("__2", ""))
        Me.phResults.Visible = False

    End Sub


    Protected Sub ddl2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl2.SelectedIndexChanged
        LoadFilterChoices(lbFilter2, Me.ddl2.SelectedValue.Replace("__2", ""))
        Me.phResults.Visible = False
    End Sub


    Protected Sub ddl3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl3.SelectedIndexChanged
        LoadFilterChoices(lbFilter3, Me.ddl3.SelectedValue.Replace("__2", ""))
        Me.phResults.Visible = False
    End Sub


    Protected Sub ddl4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl4.SelectedIndexChanged
        LoadFilterChoices(lbFilter4, Me.ddl4.SelectedValue.Replace("__2", ""))
        Me.phResults.Visible = False
    End Sub


    Protected Sub butField2_Click(sender As Object, e As EventArgs) Handles butField2.Click
        ExpandoCollapso(Me.butField2, Me.Panel2, -1)
    End Sub


    Protected Sub butField3_Click(sender As Object, e As EventArgs) Handles butField3.Click
        ExpandoCollapso(Me.butField3, Me.Panel3, -1)
    End Sub


    Protected Sub butField4_Click(sender As Object, e As EventArgs) Handles butField4.Click
        ExpandoCollapso(Me.butField4, Me.Panel4, -1)
    End Sub


    ''' <summary>
    ''' This validator ensures each selected field is different.
    ''' </summary>
    ''' <param name="source"></param>
    ''' <param name="args"></param>
    ''' <remarks></remarks>
    Protected Sub valUniqueFields_ServerValidate(source As Object, args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles valUniqueFields.ServerValidate

        args.IsValid = True
        Me.valUniqueFields.ErrorMessage = ""

        Dim f1 As String = ""
        Dim f2 As String = ""
        Dim f3 As String = ""
        Dim f4 As String = ""

        If Me.Panel1.Visible Then f1 = Me.ddl1.SelectedValue
        If Me.Panel2.Visible Then f2 = Me.ddl2.SelectedValue
        If Me.Panel3.Visible Then f3 = Me.ddl3.SelectedValue
        If Me.Panel4.Visible Then f4 = Me.ddl4.SelectedValue

        If f1 <> "" And f1 = f2 Then Me.valUniqueFields.ErrorMessage = "Please choose different a different field in field #2. "
        If f1 <> "" And f1 = f3 Then Me.valUniqueFields.ErrorMessage &= "Please choose different a different field in field #3. "
        If f1 <> "" And f1 = f4 Then Me.valUniqueFields.ErrorMessage &= "Please choose different a different field in field #4. "

        If f2 <> "" And f2 = f3 Then Me.valUniqueFields.ErrorMessage &= "Please choose different a different field in field #3. "
        If f2 <> "" And f2 = f4 Then Me.valUniqueFields.ErrorMessage &= "Please choose different a different field in field #4. "

        If f3 <> "" And f3 = f4 Then Me.valUniqueFields.ErrorMessage &= "Please choose different a different field in field #4. "

        If Me.valUniqueFields.ErrorMessage <> "" Then args.IsValid = False

    End Sub


    Protected Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click

        'Cancel out if there's a problem with the selections on the form.
        If Not Page.IsValid Then Return

        Try
            Dim filterText As String = ""
            Dim countingHouseholds As Boolean = (Me.rblHorC.SelectedValue = "households")
            Dim countingClients As Boolean = True
            Dim fieldCount As Integer = 0

            'FLUSH OUT ALL THE OUTPUT FIELDS.
            Me.Label1.Text = ""
            Me.lblQryShort.Text = ""
            Me.gv1.Visible = False

            'START BUILDING THE QUERY DESCRIPTION.
            Me.lblQryShort.Text = "<h3>YOUR CUSTOM HMISarc REPORT</h3><p>Step 1: You selected "
            If Me.lbPtypes.SelectedIndex = 0 Then
                Me.lblQryShort.Text = String.Format("{0} all project types.</p>", Me.lblQryShort.Text)
            Else
                Me.lblQryShort.Text = String.Format("{0} {1} project type(s): {2}</p>", Me.lblQryShort.Text, Me.lbPtypes.GetSelectedIndices.Count, GetSelectedTextLB(Me.lbPtypes))
            End If

            Me.lblQryShort.Text = String.Format("{0}<p>Step 2: {1}.", Me.lblQryShort.Text, Me.rblHorC.SelectedItem.Text.Replace("I want", "You're getting"))

            'THESE PARAMETERS ARE ALWAYS REQUIRED
            Dim params(4) As System.Data.SqlClient.SqlParameter
            params(0) = New System.Data.SqlClient.SqlParameter("@report_section", "get results")
            params(1) = New System.Data.SqlClient.SqlParameter("@year", My.Settings.ArchiveYear)
            params(2) = New System.Data.SqlClient.SqlParameter("@project_types", GetSelectedValuesLB(Me.lbPtypes, False))
            params(3) = New System.Data.SqlClient.SqlParameter("@totals", Me.cbTotals.Checked)
            params(4) = New System.Data.SqlClient.SqlParameter("@ip_address", Request.UserHostAddress)

            'ADD IN THE SELECTED FIELDS, ONE AT A TIME.
            If Me.Panel1.Visible AndAlso Me.ddl1.SelectedValue <> "-1" Then
                If countingHouseholds And Me.ddl1.SelectedValue = "household_type" Then countingClients = False

                'Expand the array of parameters to include three more for this field, while keeping the original 5, for a total now of 8.
                ReDim Preserve params(params.Length + 2)
                params(params.Length - 3) = New System.Data.SqlClient.SqlParameter("@count_households", countingHouseholds)
                params(params.Length - 2) = New System.Data.SqlClient.SqlParameter("@field1", Me.ddl1.SelectedValue.Replace("__2", ""))
                params(params.Length - 1) = New System.Data.SqlClient.SqlParameter("@filter1_values", GetSelectedValuesLB(Me.lbFilter1, False))

                Me.lblQryShort.Text = String.Format("{0}<p>Step 3: You're viewing {1}", Me.lblQryShort.Text, Me.ddl1.SelectedItem.Text.Replace("* ", ""))
            End If

            'FIELD 2
            If Me.Panel2.Visible AndAlso Me.ddl2.SelectedValue <> "-1" Then
                ReDim Preserve params(params.Length + 2)
                params(params.Length - 3) = New System.Data.SqlClient.SqlParameter("@field2", Me.ddl2.SelectedValue.Replace("__2", ""))
                params(params.Length - 2) = New System.Data.SqlClient.SqlParameter("@filter2_values", GetSelectedValuesLB(Me.lbFilter2, False))
                params(params.Length - 1) = New System.Data.SqlClient.SqlParameter("@field2_output", Me.cbField2output.Checked)

                Me.lblQryShort.Text = String.Format("{0} and {1}", Me.lblQryShort.Text, Me.ddl2.SelectedItem.Text.Replace("* ", ""))
            End If

            'FIELD 3
            If Me.Panel3.Visible AndAlso Me.ddl3.SelectedValue <> "-1" Then
                ReDim Preserve params(params.Length + 2)
                params(params.Length - 3) = New System.Data.SqlClient.SqlParameter("@field3", Me.ddl3.SelectedValue.Replace("__2", ""))
                params(params.Length - 2) = New System.Data.SqlClient.SqlParameter("@filter3_values", GetSelectedValuesLB(Me.lbFilter3, False))
                params(params.Length - 1) = New System.Data.SqlClient.SqlParameter("@field3_output", Me.cbField3output.Checked)

                Me.lblQryShort.Text = String.Format("{0} and {1}", Me.lblQryShort.Text, Me.ddl3.SelectedItem.Text.Replace("* ", ""))
            End If

            'FIELD 4
            If Me.Panel4.Visible AndAlso Me.ddl4.SelectedValue <> "-1" Then
                ReDim Preserve params(params.Length + 2)
                params(params.Length - 3) = New System.Data.SqlClient.SqlParameter("@field4", Me.ddl4.SelectedValue.Replace("__2", ""))
                params(params.Length - 2) = New System.Data.SqlClient.SqlParameter("@filter4_values", GetSelectedValuesLB(Me.lbFilter4, False))
                params(params.Length - 1) = New System.Data.SqlClient.SqlParameter("@field4_output", Me.cbField4output.Checked)

                Me.lblQryShort.Text = String.Format("{0} and {1}", Me.lblQryShort.Text, Me.ddl4.SelectedItem.Text.Replace("* ", ""))
            End If

            'QUERY SUMMARY - FIGURE OUT WHAT WE FILTERED AND DISPLAY THAT BACK TO THE USER.
            If Me.lbPtypes.SelectedIndex > 0 Then
                filterText = "project type(s)"
            End If
            If Me.lbFilter1.SelectedIndex > 0 Then
                filterText = String.Format("{0}{1}{2}", filterText, IIf(filterText = "", "", " and "), Me.ddl1.SelectedItem.Text)
            End If
            If Me.Panel2.Visible And Me.lbFilter2.SelectedIndex > 0 Then
                filterText = String.Format("{0}{1}{2}", filterText, IIf(filterText = "", "", " and "), Me.ddl2.SelectedItem.Text)
            End If
            If Me.Panel3.Visible And Me.lbFilter3.SelectedIndex > 0 Then
                filterText = String.Format("{0}{1}{2}", filterText, IIf(filterText = "", "", " and "), Me.ddl3.SelectedItem.Text)
            End If
            If Me.Panel4.Visible And Me.lbFilter4.SelectedIndex > 0 Then
                filterText = String.Format("{0}{1}{2}", filterText, IIf(filterText = "", "", " and "), Me.ddl4.SelectedItem.Text)
            End If

            'QUERY SUMMARY - WRAP IT UP!
            If filterText <> "" Then
                Me.lblQryShort.Text = String.Format("{0}.<br />You're filtering out some folks by {1}, so the counts below are only a portion of the Archive.</p>", Me.lblQryShort.Text, filterText)
            Else
                Me.lblQryShort.Text = String.Format("{0}.<br />You're not filtering anyone out, so the counts below represent the entire Archive.</p>", Me.lblQryShort.Text)
            End If

            'EXECUTE THE QUERY.
            Dim ds As DataSet = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(ConfigurationManager.ConnectionStrings("HMISarc").ConnectionString, CommandType.StoredProcedure, "[sp_rptArchive]", params)

            'RESULTS FOR THE BASIC COUNTS:
            Me.gv1.DataSource = ds
            Me.gv1.Columns.Clear()

            If Not countingClients Then ds.Tables(0).Columns.Remove("count_people")

            If ds.Tables(0).Rows.Count > 0 Then
                'Re-add all the columns except for the last two.
                For i As Integer = 0 To ds.Tables(0).Columns.Count - 1
                    Dim bf As BoundField = New BoundField()
                    bf.DataField = ds.Tables(0).Columns(i).ColumnName
                    bf.HtmlEncode = False
                    gv1.Columns.Insert(i, bf)
                Next

                Me.gv1.DataBind()

                'Override the header row with the more descriptive names for fields.
                If Me.gv1.Rows.Count > 0 AndAlso Me.Panel1.Visible AndAlso Me.ddl1.SelectedValue <> "-1" AndAlso Me.ddl1.SelectedValue <> "counts" Then
                    Me.gv1.HeaderRow.Cells(fieldCount).Text = Me.ddl1.SelectedItem.Text
                    fieldCount += 1
                End If

                If Me.gv1.Rows.Count > 0 AndAlso Me.Panel2.Visible AndAlso Me.ddl2.SelectedValue <> "-1" AndAlso Me.cbField2output.Checked Then
                    Me.gv1.HeaderRow.Cells(fieldCount).Text = Me.ddl2.SelectedItem.Text
                    fieldCount += 1
                End If

                If Me.gv1.Rows.Count > 0 AndAlso Me.Panel3.Visible AndAlso Me.ddl3.SelectedValue <> "-1" AndAlso Me.cbField3output.Checked Then
                    Me.gv1.HeaderRow.Cells(fieldCount).Text = Me.ddl3.SelectedItem.Text
                    fieldCount += 1
                End If

                If Me.gv1.Rows.Count > 0 AndAlso Me.Panel4.Visible AndAlso Me.ddl4.SelectedValue <> "-1" AndAlso Me.cbField4output.Checked Then
                    Me.gv1.HeaderRow.Cells(fieldCount).Text = Me.ddl4.SelectedItem.Text
                    fieldCount += 1
                End If


                If Me.gv1.Rows.Count > 0 Then
                    If countingHouseholds Then
                        Me.gv1.HeaderRow.Cells(fieldCount).Text = "Count of households"
                        fieldCount += 1
                    End If

                    If countingClients Then
                        If countingHouseholds Then Me.gv1.HeaderRow.Cells(fieldCount).Text = "Count of people in those households" Else Me.gv1.HeaderRow.Cells(fieldCount).Text = "Total"
                        fieldCount += 1
                    End If

                End If

                Me.gv1.Visible = True

            Else
                Me.lblQryShort.Text &= "<p class='alert'>No people found matching your query.</p>"

            End If


            'QUERY RESULTS, IN CONTEXT OF THE ENTIRE ARCHIVE:
            If Not countingClients Then ds.Tables(1).Columns.Remove("Clients")
            If Not countingHouseholds Then ds.Tables(1).Columns.Remove("Households")

            Me.gv2.DataSource = ds.Tables(1)
            Me.gv2.DataBind()
            Me.hRelativeResults.Visible = True

            Me.phResults.Visible = True

            'JAVASCRIPT TO RUN AFTER PAGE LOADS:
            ScriptManager.RegisterClientScriptBlock(Me.UpdatePanel1, UpdatePanel1.GetType, UpdatePanel1.ClientID, "$(function () {  $('table').stickyTableHeaders(); });", True)
            ScriptManager.RegisterStartupScript(Me.UpdatePanel1, UpdatePanel1.GetType, "scrollToResults", String.Format("setTimeout(""window.scrollTo(0,findPos('{0}'));"", 100);", Me.btnGo.ClientID), True)

        Catch ex As Exception
            'Helpful for debugging, as output won't be obvious on the screen since it's white on white.
            Me.Label1.Text = String.Format("<p>Sorry, had some trouble producing this report.</p><p style='color:white;'>{0}.</p>", ex.Message)
            Me.hRelativeResults.Visible = False

        End Try

    End Sub


    Private Sub gv1_DataBound(sender As Object, e As System.EventArgs) Handles gv1.DataBound
        Me.gv1.HeaderRow.TableSection = TableRowSection.TableHeader
    End Sub


    Private Sub gv1_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gv1.RowDataBound
        For Each cell As WebControls.TableCell In e.Row.Cells
            If cell.Text.ToLower = "yes" Or cell.Text.ToLower = "total" Then cell.Text = String.Format("<b>{0}</b>", cell.Text)
        Next
    End Sub


#End Region


#Region "Helper functions"

    ''' <summary>
    ''' Loads list of Archive fields from which to select data.
    ''' </summary>
    ''' <param name="ddlField">The dropdownlist which will hold the list of fields.</param>
    ''' <param name="lbFilter">The listbox of filter values corresponding to the dropdownlist; this list will be flushed.</param>
    ''' <param name="fieldType">H = household fields; C = client/people fields.</param>
    ''' <remarks></remarks>
    Private Sub LoadFields(ddlField As DropDownList, lbFilter As ListBox, fieldType As String)

        Dim params(2) As System.Data.SqlClient.SqlParameter

        params(0) = New System.Data.SqlClient.SqlParameter("@report_section", "get fields")
        params(1) = New System.Data.SqlClient.SqlParameter("@year", My.Settings.ArchiveYear)
        params(2) = New System.Data.SqlClient.SqlParameter("@get_field_types", fieldType)

        Dim ds As DataSet = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(ConfigurationManager.ConnectionStrings("HMISarc").ConnectionString, CommandType.StoredProcedure, "[sp_rptArchive]", params)

        ddlField.Items.Clear()

        ddlField.DataSource = ds.Tables(0)
        ddlField.DataTextField = "field_description"
        ddlField.DataValueField = "field_name"
        ddlField.DataBind()

        ddlField.Items.Insert(0, New ListItem("(choose your field here)", "-1"))
        ddlField.Items(0).Attributes.Add("disabled", "true")

        'Flush the list of values for the field by which a user can filter.
        lbFilter.Items.Clear()

    End Sub


    ''' <summary>
    ''' Loads filter choices from the Archive table into the given listbox.
    ''' </summary>
    ''' <param name="lb">A listbox.</param>
    ''' <param name="sourceField">The field in the Archive to scan for possible values.</param>
    ''' <remarks></remarks>
    Private Sub LoadFilterChoices(lb As ListBox, sourceField As String)

        'First clear anything in the list that might be remaining from a previous choice in the field.
        lb.Items.Clear()
        Me.Label1.Text = ""

        Try
            If sourceField <> "counts" Then

                Dim params(2) As System.Data.SqlClient.SqlParameter

                params(0) = New System.Data.SqlClient.SqlParameter("@report_section", "get filter choices")
                params(1) = New System.Data.SqlClient.SqlParameter("@year", My.Settings.ArchiveYear)
                params(2) = New System.Data.SqlClient.SqlParameter("@field1", sourceField)

                Dim ds As DataSet = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(ConfigurationManager.ConnectionStrings("HMISarc").ConnectionString, CommandType.StoredProcedure, "[sp_rptArchive]", params)

                lb.DataSource = ds
                lb.DataTextField = "stripped"
                lb.DataValueField = sourceField
                lb.DataBind()

                'Need to convert most HTML to codes.  EXCEPT for single quotes which must remain as single quotes due to the way the UpdatePanel facilitates the postback.
                For Each li As ListItem In lb.Items
                    li.Value = Server.HtmlEncode(li.Value).Replace("&#39;", "'")
                Next

            End If

        Catch ex As Exception
            'Helpful for debugging, as output won't be obvious on the screen since it's white on white.
            Me.Label1.Visible = True
            Me.Label1.Text = String.Format("<p>Sorry, unable to access this field.</p><p style='color:white;'>{0}.</p>", ex.Message)

        Finally
            'Add an "all" choice at the very top of the list and make that the default choice.
            lb.Items.Insert(0, New ListItem("(all)", "-1"))
            lb.Items(0).Selected = True

        End Try

    End Sub


    ''' <summary>
    ''' Shows or hides a server control based on its current status.
    ''' </summary>
    ''' <param name="aButton">A linkbutton used to control the visibility of the server control.</param>
    ''' <param name="aPanel">The panel to be shown/hidden.</param>
    ''' <param name="openClosed">Set to -1 to simply reverse the panel's current status.  Set to 0 to force the panel closed.  Set to 1 to force the panel open.</param>
    ''' <remarks></remarks>
    Private Sub ExpandoCollapso(aButton As LinkButton, aPanel As Control, openClosed As Integer)
        If aPanel.Visible Or openClosed = 0 Then
            aButton.Text = aButton.Text.Replace("minus", "plus")
            aPanel.Visible = False
        ElseIf aPanel.Visible = False Or openClosed = 1 Then
            aButton.Text = aButton.Text.Replace("plus", "minus")
            aPanel.Visible = True
        End If
    End Sub


    ''' <summary>
    ''' Returns a comma-separated string of selected values in the given listbox.
    ''' </summary>
    ''' <param name="LB">The listbox.</param>
    ''' <param name="GetAllValues">Get all values, whether or not they are selected.</param>
    ''' <returns>Comma-separated list of selected values.</returns>
    ''' <remarks></remarks>
    Public Function GetSelectedValuesLB(ByVal LB As ListBox, ByVal GetAllValues As Boolean) As String
        Dim li As ListItem
        Dim selectedValues As String = ""
        For Each li In LB.Items
            If li.Selected = True Or GetAllValues Then
                selectedValues &= String.Format("'{0}',", Server.HtmlDecode(li.Value).Replace("'", "''"))
            End If
        Next
        If selectedValues.Length > 0 Then selectedValues = Left(selectedValues, selectedValues.Length - 1) 'Strips off tailing comma
        Return selectedValues
    End Function


    ''' <summary>
    ''' Returns a comma-separated list of selected text (not values) in the given listbox.
    ''' </summary>
    ''' <param name="LB">The listbox.</param>
    ''' <returns>Comma-separated list of selected text.</returns>
    ''' <remarks></remarks>
    Public Function GetSelectedTextLB(ByVal LB As ListBox) As String
        Dim li As ListItem
        Dim selectedValues As String = ""
        For Each li In LB.Items
            If li.Selected = True Then
                selectedValues &= String.Format("{0}, ", li.Text)
            End If
        Next
        If selectedValues.Length > 0 Then selectedValues = Left(selectedValues, selectedValues.Length - 2) 'Strips off tailing comma
        Return selectedValues
    End Function

#End Region 'Helper functions


End Class
